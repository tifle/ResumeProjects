//
//  ListAndNavigationTutorialTests.swift
//  ListAndNavigationTutorialTests
//
//  Created by Maggie Hillebrecht on 4/1/25.
//

import Testing
@testable import ListAndNavigationTutorial

struct ListAndNavigationTutorialTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
